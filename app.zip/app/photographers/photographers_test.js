'use strict';

describe('myApp.photographers module', function() {

  beforeEach(module('myApp.photographers'));

  describe('photographers controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view1Ctrl = $controller('photographersCtrl');
      expect(photographersCtrl).toBeDefined();
    }));

  });
});