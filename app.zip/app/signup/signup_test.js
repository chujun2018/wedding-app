'use strict';

describe('myApp.signup module', function() {

  beforeEach(module('myApp.signup'));

  describe('signup controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view1Ctrl = $controller('signupCtrl');
      expect(signupCtrl).toBeDefined();
    }));

  });
});