'use strict';

describe('myApp.search module', function() {

  beforeEach(module('myApp.search'));

  describe('search controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var searchCtrl = $controller('searchCtrl');
      expect(searchCtrl).toBeDefined();
    }));

  });
});